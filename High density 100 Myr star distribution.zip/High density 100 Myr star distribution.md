```python
import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
pd.set_option('display.max_columns', None)
```


```python
data = np.loadtxt("C:\Ahzam\MSc Astrophysics\Project\Python\data's\TIme 100 Myr High Density\data_OrBC0p3F1p61pSmFS1H_02 (1).dat")
data = pd.DataFrame(data, columns =['Snapshot_no', 'Time', 'Particle_index','particle_id','mass','x','y','z','v_x','v_y','v_z','id_close_encounter_star','close_encounter_time','close_encounter_distance'])
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Snapshot_no</th>
      <th>Time</th>
      <th>Particle_index</th>
      <th>particle_id</th>
      <th>mass</th>
      <th>x</th>
      <th>y</th>
      <th>z</th>
      <th>v_x</th>
      <th>v_y</th>
      <th>v_z</th>
      <th>id_close_encounter_star</th>
      <th>close_encounter_time</th>
      <th>close_encounter_distance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.119013</td>
      <td>-0.078132</td>
      <td>0.465162</td>
      <td>-0.087114</td>
      <td>-0.529624</td>
      <td>0.379493</td>
      <td>-0.961670</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>0.240326</td>
      <td>0.998230</td>
      <td>-0.292917</td>
      <td>0.417159</td>
      <td>-0.496843</td>
      <td>0.368251</td>
      <td>-0.965661</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>0.293598</td>
      <td>0.998112</td>
      <td>-0.300038</td>
      <td>0.408027</td>
      <td>-0.531041</td>
      <td>0.356280</td>
      <td>-0.971264</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>4.0</td>
      <td>4.0</td>
      <td>0.179425</td>
      <td>1.001702</td>
      <td>-0.317693</td>
      <td>0.421911</td>
      <td>-0.529452</td>
      <td>0.380896</td>
      <td>-1.043984</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0</td>
      <td>0.000000</td>
      <td>5.0</td>
      <td>5.0</td>
      <td>0.109202</td>
      <td>1.002945</td>
      <td>-0.314677</td>
      <td>0.414525</td>
      <td>-0.513722</td>
      <td>0.373348</td>
      <td>-1.035795</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>76495</th>
      <td>50.0</td>
      <td>100.000008</td>
      <td>1496.0</td>
      <td>1489.0</td>
      <td>0.576686</td>
      <td>-12.347045</td>
      <td>-12.342547</td>
      <td>-0.229994</td>
      <td>-0.442023</td>
      <td>-0.358168</td>
      <td>-0.220871</td>
      <td>1497.0</td>
      <td>7.058179</td>
      <td>0.000229</td>
    </tr>
    <tr>
      <th>76496</th>
      <td>50.0</td>
      <td>100.000008</td>
      <td>1497.0</td>
      <td>1497.0</td>
      <td>0.209608</td>
      <td>-12.347564</td>
      <td>-12.341831</td>
      <td>-0.229571</td>
      <td>0.424511</td>
      <td>-0.159249</td>
      <td>0.421199</td>
      <td>1486.0</td>
      <td>0.070094</td>
      <td>0.002449</td>
    </tr>
    <tr>
      <th>76497</th>
      <td>50.0</td>
      <td>100.000008</td>
      <td>1498.0</td>
      <td>1498.0</td>
      <td>0.164270</td>
      <td>-0.509838</td>
      <td>3.000651</td>
      <td>-2.795829</td>
      <td>0.315756</td>
      <td>0.218309</td>
      <td>0.058819</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>76498</th>
      <td>50.0</td>
      <td>100.000008</td>
      <td>1499.0</td>
      <td>1499.0</td>
      <td>0.176044</td>
      <td>-3.215745</td>
      <td>-5.168353</td>
      <td>-0.749804</td>
      <td>0.019957</td>
      <td>-0.109699</td>
      <td>0.271368</td>
      <td>1485.0</td>
      <td>0.166264</td>
      <td>0.003268</td>
    </tr>
    <tr>
      <th>76499</th>
      <td>50.0</td>
      <td>100.000008</td>
      <td>1500.0</td>
      <td>1500.0</td>
      <td>0.265313</td>
      <td>-1.262345</td>
      <td>4.183960</td>
      <td>0.626525</td>
      <td>-0.523068</td>
      <td>-0.250872</td>
      <td>0.187271</td>
      <td>1499.0</td>
      <td>0.554663</td>
      <td>0.004856</td>
    </tr>
  </tbody>
</table>
<p>76500 rows × 14 columns</p>
</div>




```python
import matplotlib.pyplot as plt

df_snapshot0 = data[data['Snapshot_no'] == 0]
df_snapshot0 = df_snapshot0.sort_values(by='particle_id')
df_snapshot0 = df_snapshot0.reset_index(drop=True)

x = df_snapshot0['x']
y = df_snapshot0['y']
z = df_snapshot0['z']


fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(x, y, z)

ax.set_xlabel('X axis', labelpad=10)  # adjust the labelpad value as needed
ax.set_ylabel('Y axis', labelpad=10)
ax.set_zlabel('Z axis', labelpad=10)
ax.set_title('Initial condition')

ax.set_xticklabels(ax.get_xticks(), rotation = 45)

plt.show()

```

    C:\Users\Ahzam Ahmed\AppData\Local\Temp\ipykernel_26844\3987511552.py:21: UserWarning: FixedFormatter should only be used together with FixedLocator
      ax.set_xticklabels(ax.get_xticks(), rotation = 45)
    


    
![png](output_2_1.png)
    



```python
import matplotlib.pyplot as plt

df_snapshot30 = data[data['Snapshot_no'] == 15]
df_snapshot30 = df_snapshot30.sort_values(by='particle_id')
df_snapshot30 = df_snapshot30.reset_index(drop=True)

x = df_snapshot30['x']
y = df_snapshot30['y']
z = df_snapshot30['z']

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(x, y, z)

ax.set_xlabel('X axis', labelpad=10)  # adjust the labelpad value as needed
ax.set_ylabel('Y axis', labelpad=10)
ax.set_zlabel('Z axis', labelpad=10)

plt.show()
```


    
![png](output_3_0.png)
    



```python
df_snapshot30
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Snapshot_no</th>
      <th>Time</th>
      <th>Particle_index</th>
      <th>particle_id</th>
      <th>mass</th>
      <th>x</th>
      <th>y</th>
      <th>z</th>
      <th>v_x</th>
      <th>v_y</th>
      <th>v_z</th>
      <th>id_close_encounter_star</th>
      <th>close_encounter_time</th>
      <th>close_encounter_distance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>468.0</td>
      <td>1.0</td>
      <td>0.119013</td>
      <td>-0.776759</td>
      <td>-0.175554</td>
      <td>-1.604844</td>
      <td>-0.049582</td>
      <td>-0.508465</td>
      <td>0.468300</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>469.0</td>
      <td>2.0</td>
      <td>0.240326</td>
      <td>-90.763772</td>
      <td>50.326585</td>
      <td>-19.906211</td>
      <td>-3.006439</td>
      <td>1.621780</td>
      <td>-0.629237</td>
      <td>664.0</td>
      <td>0.178855</td>
      <td>0.004842</td>
    </tr>
    <tr>
      <th>2</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>470.0</td>
      <td>3.0</td>
      <td>0.293598</td>
      <td>-2.113907</td>
      <td>7.069316</td>
      <td>-5.766054</td>
      <td>-0.300985</td>
      <td>0.168413</td>
      <td>0.015927</td>
      <td>5.0</td>
      <td>0.161864</td>
      <td>0.004863</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>471.0</td>
      <td>4.0</td>
      <td>0.179425</td>
      <td>0.419360</td>
      <td>0.429816</td>
      <td>-0.040957</td>
      <td>-0.029681</td>
      <td>-0.671160</td>
      <td>0.886645</td>
      <td>76.0</td>
      <td>0.196508</td>
      <td>0.004858</td>
    </tr>
    <tr>
      <th>4</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>472.0</td>
      <td>5.0</td>
      <td>0.109202</td>
      <td>1.044293</td>
      <td>-0.998694</td>
      <td>0.427346</td>
      <td>-0.316118</td>
      <td>0.011165</td>
      <td>-0.189829</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1495</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>1495.0</td>
      <td>1496.0</td>
      <td>0.401709</td>
      <td>-3.183409</td>
      <td>3.556409</td>
      <td>-3.123894</td>
      <td>-0.241279</td>
      <td>0.336941</td>
      <td>-0.321974</td>
      <td>461.0</td>
      <td>1.253943</td>
      <td>0.004858</td>
    </tr>
    <tr>
      <th>1496</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>1497.0</td>
      <td>1497.0</td>
      <td>0.209608</td>
      <td>5.803350</td>
      <td>8.560384</td>
      <td>-3.168380</td>
      <td>0.788232</td>
      <td>0.239596</td>
      <td>0.427419</td>
      <td>1486.0</td>
      <td>0.070094</td>
      <td>0.002449</td>
    </tr>
    <tr>
      <th>1497</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>1498.0</td>
      <td>1498.0</td>
      <td>0.164270</td>
      <td>0.457606</td>
      <td>0.115092</td>
      <td>4.564270</td>
      <td>-0.458777</td>
      <td>-0.333381</td>
      <td>0.238096</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1498</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>1499.0</td>
      <td>1499.0</td>
      <td>0.176044</td>
      <td>0.293106</td>
      <td>3.727033</td>
      <td>-0.580337</td>
      <td>-0.127560</td>
      <td>-0.590764</td>
      <td>-0.306645</td>
      <td>1485.0</td>
      <td>0.166264</td>
      <td>0.003268</td>
    </tr>
    <tr>
      <th>1499</th>
      <td>15.0</td>
      <td>30.000004</td>
      <td>1500.0</td>
      <td>1500.0</td>
      <td>0.265313</td>
      <td>0.366512</td>
      <td>1.599402</td>
      <td>1.583164</td>
      <td>0.418350</td>
      <td>0.036520</td>
      <td>-0.622614</td>
      <td>1499.0</td>
      <td>0.554663</td>
      <td>0.004856</td>
    </tr>
  </tbody>
</table>
<p>1500 rows × 14 columns</p>
</div>




```python
df_snapshot100 = data[data['Snapshot_no'] == 50]
df_snapshot100 = df_snapshot100.sort_values(by='particle_id')
df_snapshot100 = df_snapshot100.reset_index(drop=True)

x = df_snapshot100['x']
y = df_snapshot100['y']
z = df_snapshot100['z']

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(x, y, z)

ax.set_xlabel('X axis', labelpad=10)  # adjust the labelpad value as needed
ax.set_ylabel('Y axis', labelpad=10)
ax.set_zlabel('Z axis', labelpad=10)
#ax.set_xlim3d(-1000, 1000)
#ax.set_ylim3d(-1000, 1000)
#ax.set_zlim3d(-1000, 1000)
plt.show()
```


    
![png](output_5_0.png)
    



```python

```
